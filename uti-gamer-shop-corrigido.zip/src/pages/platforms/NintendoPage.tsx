import React from 'react';
import PlatformPage from '@/components/PlatformPage';

const NintendoPage: React.FC = () => {
  return <PlatformPage slug="nintendo" />;
};

export default NintendoPage;


