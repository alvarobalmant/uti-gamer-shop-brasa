
import { Database } from "../integrations/supabase/types";

// Base type for Special Section from the database
export type SpecialSection = Database["public"]["Tables"]["special_sections"]["Row"] & {
  background_type?: 'color' | 'image';
  background_value?: string;
  background_image_position?: 'center' | 'top' | 'bottom' | 'left' | 'right';
};

// Base type for Special Section Element from the database
export type SpecialSectionElement = Database["public"]["Tables"]["special_section_elements"]["Row"] & {
  content_ids?: string[];
};

// Base type for Special Section Grid Layout from the database
export type SpecialSectionGridLayout = Database["public"]["Tables"]["special_section_grid_layouts"]["Row"];

// Input type for creating a new Special Section (excluding auto-generated fields)
export type SpecialSectionCreateInput = Omit<
  SpecialSection,
  "id" | "created_at" | "updated_at"
>;

// Input type for updating an existing Special Section (all fields optional)
export type SpecialSectionUpdateInput = Partial<SpecialSectionCreateInput>;

// Input type for creating a new Special Section Element
export type SpecialSectionElementCreateInput = Omit<
  SpecialSectionElement,
  "id" | "created_at" | "updated_at"
>;

// Input type for updating an existing Special Section Element
export type SpecialSectionElementUpdateInput = Partial<SpecialSectionElementCreateInput>;

// Input type for creating a new Special Section Grid Layout
export type SpecialSectionGridLayoutCreateInput = Omit<
  SpecialSectionGridLayout,
  "id" | "created_at" | "updated_at"
>;

// Input type for updating an existing Special Section Grid Layout
export type SpecialSectionGridLayoutUpdateInput = Partial<SpecialSectionGridLayoutCreateInput>;

// Add the missing CarouselConfig type
export interface CarouselConfig {
  title?: string;
  selection_mode?: 'tags' | 'products' | 'combined';
  tag_ids?: string[];
  product_ids?: string[];
}

// Define new banner types for flexibility
export type BannerType = 'full_width' | 'half_width' | 'third_width' | 'quarter_width' | 'product_highlight';

export interface BannerConfig {
  type: BannerType;
  image_url?: string;
  link_url?: string;
  title?: string;
  subtitle?: string;
  button_text?: string;
  enable_hover_animation?: boolean; // New property for hover animation control
}

// Define a row of banners, allowing different layouts per row
export interface BannerRowConfig {
  row_id: string; // Unique ID for the row
  layout: '1_col_full' | '2_col_half' | '3_col_third' | '4_col_quarter'; // Predefined layouts
  banners: BannerConfig[]; // Array of banners for this row, matching the layout
}

// Update FixedContentFormData to use dynamic banner rows
export interface FixedContentFormData {
  banner_rows?: BannerRowConfig[]; // Array of banner rows
  carrossel_1?: CarouselConfig;
  carrossel_2?: CarouselConfig;
}




