
export interface CustomPlatformPageProps {
  pageSlug: string;
}
